package com.rong.litswipecard.cardstack.cardgrid.swipe;

import android.view.MotionEvent;
import com.rong.litswipecard.cardstack.cardgrid.swipe.model.Pointer;
import com.rong.litswipecard.cardstack.model.SwipeDirection;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 滑动手势检测器
 * 负责检测和处理滑动、点击等手势操作
 */
public final class SwipeGestureDetector {

    /**
     * 触摸拦截条件
     */
    private final TouchInterceptPredicate touchInterceptPredicate;

    /**
     * 滑动动作识别器
     */
    private final SwipeActionRecognizer swipeActionRecognizer;

    /**
     * 点击动作识别器
     */
    private final ClickActionRecognizer clickActionRecognizer;

    /**
     * 手势监听器
     */
    private OnGestureListener onGestureListener;

    /**
     * 指针跟踪器
     */
    private final PointerTracker pointerTracker;

    /**
     * 触摸拦截器
     */
    private final TouchInterceptor touchInterceptor;

    /**
     * 动作识别器
     */
    private final ActionRecognizer actionRecognizer;

    /**
     * 动作基类
     * 定义了手势可能产生的动作类型
     */
    private static abstract class Action {

        /**
         * 点击动作
         */
        public static final class CLICK extends Action {
            /**
             * 单例实例
             */
            @NotNull
            public static final CLICK INSTANCE = new CLICK();

            private CLICK() {
                super(null);
            }
        }

        /**
         * 恢复动作
         */
        public static final class RECOVER extends Action {
            /**
             * 单例实例
             */
            @NotNull
            public static final RECOVER INSTANCE = new RECOVER();

            private RECOVER() {
                super(null);
            }
        }

        /**
         * 滑动动作
         */
        public static final class SWIPE extends Action {
            /**
             * 滑动方向
             */
            private final SwipeDirection swipeDirection;

            /**
             * 构造函数
             * @param swipeDirection 滑动方向
             */
            public SWIPE(@NotNull SwipeDirection swipeDirection) {
                super(null);
                Intrinsics.checkNotNullParameter(swipeDirection, "swipeDirection");
                this.swipeDirection = swipeDirection;
            }

            /**
             * 创建副本，可以修改部分属性
             * @param swipeDirection 新的滑动方向
             * @return 新的滑动动作对象
             */
            public static SWIPE copy$default(SWIPE swipe, SwipeDirection swipeDirection, int flags, Object obj) {
                if ((flags & 1) != 0) {
                    swipeDirection = swipe.swipeDirection;
                }
                return swipe.copy(swipeDirection);
            }

            /**
             * 获取第一个组件（滑动方向）
             * @return 滑动方向
             */
            @NotNull
            public final SwipeDirection getSwipeDirection() {
                return this.swipeDirection;
            }

            /**
             * 创建副本
             * @param swipeDirection 新的滑动方向
             * @return 新的滑动动作对象
             */
            @NotNull
            public final SWIPE copy(@NotNull SwipeDirection swipeDirection) {
                Intrinsics.checkNotNullParameter(swipeDirection, "swipeDirection");
                return new SWIPE(swipeDirection);
            }

            /**
             * 判断相等性
             * @param other 另一个对象
             * @return 是否相等
             */
            @Override
            public boolean equals(@Nullable Object other) {
                if (this == other) {
                    return true;
                }
                return (other instanceof SWIPE) && this.swipeDirection == ((SWIPE) other).swipeDirection;
            }

            /**
             * 计算哈希码
             * @return 哈希码
             */
            @Override
            public int hashCode() {
                return this.swipeDirection.hashCode();
            }

            /**
             * 转换为字符串表示
             * @return 字符串表示
             */
            @NotNull
            @Override
            public String toString() {
                return "SWIPE(swipeDirection=" + this.swipeDirection + ')';
            }
        }

        /**
         * 创建动作
         */
        public Action(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        /**
         * 私有构造函数
         */
        private Action() {
        }
    }

    /**
     * 点击动作识别器接口
     */
    public interface ClickActionRecognizer {
        /**
         * 判断是否为点击动作
         * @param pointer 指针
         * @return 是否为点击
         */
        boolean isClick(@NotNull Pointer pointer);
    }

    /**
     * 手势监听器接口
     */
    public interface OnGestureListener {
        /**
         * 点击回调
         * @param pointer 指针
         */
        void onClick(@NotNull Pointer pointer);

        /**
         * 移动回调
         * @param pointer 指针
         */
        void onMove(@NotNull Pointer pointer);

        /**
         * 恢复回调
         * @param pointer 指针
         */
        void onRecover(@NotNull Pointer pointer);

        /**
         * 滑动回调
         * @param pointer 指针
         * @param swipeDirection 滑动方向
         */
        void onSwipe(@NotNull Pointer pointer, @NotNull SwipeDirection swipeDirection);
    }

    /**
     * 滑动动作识别器接口
     */
    public interface SwipeActionRecognizer {
        /**
         * 查找滑动方向
         * @param pointer 指针
         * @return 滑动方向
         */
        @NotNull
        SwipeDirection findSwipeDirection(@NotNull Pointer pointer);
    }

    /**
     * 触摸拦截条件接口
     */
    public interface TouchInterceptPredicate {
        /**
         * 是否应该拦截触摸事件
         * @param pointer 指针
         * @return 是否拦截
         */
        boolean shouldIntercept(@NotNull Pointer pointer);
    }

    /**
     * 动作识别器，实现PointerTracker.Listener接口
     * 用于识别指针动作并触发相应回调
     */
    private final class ActionRecognizer implements PointerTracker.Listener {
        
        public ActionRecognizer() {
        }

        /**
         * 根据指针状态识别动作类型
         * @param pointer 指针
         * @return 识别出的动作
         */
        private final Action recognizeAction(Pointer pointer) {
            if (SwipeGestureDetector.this.getClickActionRecognizer$cardstack_release().isClick(pointer)) {
                return Action.CLICK.INSTANCE;
            }
            SwipeDirection swipeDirection = SwipeGestureDetector.this.getSwipeActionRecognizer$cardstack_release().findSwipeDirection(pointer);
            return swipeDirection != SwipeDirection.NONE ? new Action.SWIPE(swipeDirection) : Action.RECOVER.INSTANCE;
        }

        @Override
        public void onPointerDown(@NotNull Pointer pointer) {
            Intrinsics.checkNotNullParameter(pointer, "pointer");
            // 指针按下时不需要特殊处理
        }

        @Override
        public void onPointerMove(@NotNull Pointer pointer) {
            Intrinsics.checkNotNullParameter(pointer, "pointer");
            OnGestureListener listener = SwipeGestureDetector.this.getOnGestureListener$cardstack_release();
            if (listener != null) {
                listener.onMove(pointer);
            }
        }

        @Override
        public void onPointerUp(@NotNull Pointer pointer) {
            Intrinsics.checkNotNullParameter(pointer, "pointer");
            Action action = recognizeAction(pointer);
            
            if (action instanceof Action.CLICK) {
                OnGestureListener listener = SwipeGestureDetector.this.getOnGestureListener$cardstack_release();
                if (listener != null) {
                    listener.onClick(pointer);
                }
            } else if (action instanceof Action.SWIPE) {
                OnGestureListener listener = SwipeGestureDetector.this.getOnGestureListener$cardstack_release();
                if (listener != null) {
                    listener.onSwipe(pointer, ((Action.SWIPE) action).getSwipeDirection());
                }
            } else {
                OnGestureListener listener = SwipeGestureDetector.this.getOnGestureListener$cardstack_release();
                if (listener != null) {
                    listener.onRecover(pointer);
                }
            }
        }
    }

    /**
     * 触摸拦截器，实现PointerTracker.Listener接口
     * 用于判断是否应该拦截触摸事件
     */
    private final class TouchInterceptor implements PointerTracker.Listener {
        /**
         * 是否已拦截触摸事件
         */
        private boolean isIntercepting;

        public TouchInterceptor() {
        }

        /**
         * 检查是否应该拦截指针
         * @param pointer 指针
         */
        private final void checkShouldIntercept(Pointer pointer) {
            if (this.isIntercepting || !SwipeGestureDetector.this.getTouchInterceptPredicate$cardstack_release().shouldIntercept(pointer)) {
                return;
            }
            this.isIntercepting = true;
        }

        /**
         * 重置拦截状态
         */
        private final void resetInterceptState() {
            if (SwipeGestureDetector.this.pointerTracker.getPointers$cardstack_release().isEmpty()) {
                this.isIntercepting = false;
                SwipeGestureDetector.this.pointerTracker.release$cardstack_release();
            }
        }

        /**
         * 获取当前是否正在拦截
         * @return 是否正在拦截
         */
        public final boolean isIntercepting() {
            return this.isIntercepting;
        }

        @Override
        public void onPointerDown(@NotNull Pointer pointer) {
            Intrinsics.checkNotNullParameter(pointer, "pointer");
            // 指针按下时不需要特殊处理
        }

        @Override
        public void onPointerMove(@NotNull Pointer pointer) {
            Intrinsics.checkNotNullParameter(pointer, "pointer");
            checkShouldIntercept(pointer);
            if (this.isIntercepting) {
                SwipeGestureDetector.this.actionRecognizer.onPointerMove(pointer);
            }
        }

        @Override
        public void onPointerUp(@NotNull Pointer pointer) {
            Intrinsics.checkNotNullParameter(pointer, "pointer");
            if (this.isIntercepting) {
                SwipeGestureDetector.this.actionRecognizer.onPointerUp(pointer);
            }
            resetInterceptState();
        }
    }

    /**
     * 构造函数
     * @param touchInterceptPredicate 触摸拦截条件
     * @param swipeActionRecognizer 滑动动作识别器
     * @param clickActionRecognizer 点击动作识别器
     */
    public SwipeGestureDetector(
            @NotNull TouchInterceptPredicate touchInterceptPredicate,
            @NotNull SwipeActionRecognizer swipeActionRecognizer,
            @NotNull ClickActionRecognizer clickActionRecognizer) {
        Intrinsics.checkNotNullParameter(touchInterceptPredicate, "touchInterceptPredicate");
        Intrinsics.checkNotNullParameter(swipeActionRecognizer, "swipeActionRecognizer");
        Intrinsics.checkNotNullParameter(clickActionRecognizer, "clickActionRecognizer");
        
        this.touchInterceptPredicate = touchInterceptPredicate;
        this.swipeActionRecognizer = swipeActionRecognizer;
        this.clickActionRecognizer = clickActionRecognizer;
        
        PointerTracker pointerTracker = new PointerTracker();
        this.pointerTracker = pointerTracker;
        
        TouchInterceptor touchInterceptor = new TouchInterceptor();
        this.touchInterceptor = touchInterceptor;
        
        this.actionRecognizer = new ActionRecognizer();
        
        pointerTracker.setListener$cardstack_release(touchInterceptor);
    }

    /**
     * 获取点击动作识别器
     * @return 点击动作识别器
     */
    @NotNull
    public final ClickActionRecognizer getClickActionRecognizer$cardstack_release() {
        return this.clickActionRecognizer;
    }

    /**
     * 获取手势监听器
     * @return 手势监听器
     */
    @Nullable
    public final OnGestureListener getOnGestureListener$cardstack_release() {
        return this.onGestureListener;
    }

    /**
     * 获取滑动动作识别器
     * @return 滑动动作识别器
     */
    @NotNull
    public final SwipeActionRecognizer getSwipeActionRecognizer$cardstack_release() {
        return this.swipeActionRecognizer;
    }

    /**
     * 获取触摸拦截条件
     * @return 触摸拦截条件
     */
    @NotNull
    public final TouchInterceptPredicate getTouchInterceptPredicate$cardstack_release() {
        return this.touchInterceptPredicate;
    }

    /**
     * 处理触摸事件
     * @param event 触摸事件
     */
    public final void handleTouchEvent$cardstack_release(@NotNull MotionEvent event) {
        Intrinsics.checkNotNullParameter(event, "event");
        this.pointerTracker.track$cardstack_release(event);
    }

    /**
     * 设置手势监听器
     * @param onGestureListener 手势监听器
     */
    public final void setOnGestureListener$cardstack_release(@Nullable OnGestureListener onGestureListener) {
        this.onGestureListener = onGestureListener;
    }

    /**
     * 判断是否应该拦截触摸事件
     * @param event 触摸事件
     * @return 是否应该拦截
     */
    public final boolean shouldInterceptTouchEvent$cardstack_release(@NotNull MotionEvent event) {
        Intrinsics.checkNotNullParameter(event, "event");
        handleTouchEvent$cardstack_release(event);
        return this.touchInterceptor.isIntercepting();
    }
}