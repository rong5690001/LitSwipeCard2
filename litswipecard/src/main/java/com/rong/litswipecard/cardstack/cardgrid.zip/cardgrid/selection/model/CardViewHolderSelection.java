package com.rong.litswipecard.cardstack.cardgrid.selection.model;

import com.rong.litswipecard.cardstack.cardgrid.model.Point;
import com.rong.litswipecard.cardstack.cardgrid.swipe.model.Pointer;
import com.rong.litswipecard.cardstack.view.CardViewHolder;
import java.util.LinkedHashSet;
import java.util.Set;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 卡片视图持有者选择模型
 * 表示一个被选中的卡片及其相关的触摸指针
 */
public final class CardViewHolderSelection {

    /**
     * 关联的卡片视图持有者
     */
    private final CardViewHolder<?> cardViewHolder;

    /**
     * 首次触摸点
     */
    private final Point firstTouchPoint;

    /**
     * 主指针的偏移量
     */
    private Point primaryPointerOffset;

    /**
     * 与该选择关联的指针集合
     */
    private final LinkedHashSet<Pointer> pointerSet;

    /**
     * 构造函数
     * @param cardViewHolder 卡片视图持有者
     * @param firstTouchPoint 首次触摸点
     */
    public CardViewHolderSelection(@NotNull CardViewHolder<?> cardViewHolder, @NotNull Point firstTouchPoint) {
        Intrinsics.checkNotNullParameter(cardViewHolder, "cardViewHolder");
        Intrinsics.checkNotNullParameter(firstTouchPoint, "firstTouchPoint");
        this.cardViewHolder = cardViewHolder;
        this.firstTouchPoint = firstTouchPoint;
        this.primaryPointerOffset = Point.Companion.getZero();
        this.pointerSet = new LinkedHashSet<>();
    }

    /**
     * 添加指针到该选择
     * @param pointer 要添加的指针
     */
    public final void addPointer$cardstack_release(@NotNull Pointer pointer) {
        Intrinsics.checkNotNullParameter(pointer, "pointer");
        this.pointerSet.add(pointer);
    }

    /**
     * 获取卡片视图持有者
     * @return 卡片视图持有者
     */
    @NotNull
    public final CardViewHolder<?> component1() {
        return this.cardViewHolder;
    }

    /**
     * 获取首次触摸点
     * @return 首次触摸点
     */
    @NotNull
    public final Point component2() {
        return this.firstTouchPoint;
    }

    /**
     * 获取主指针
     * @return 主指针，可能为null
     */
    @Nullable
    public final Pointer component3() {
        return getPrimaryPointer$cardstack_release();
    }

    /**
     * 获取主指针偏移量
     * @return 主指针偏移量
     */
    @NotNull
    public final Point component4() {
        return this.primaryPointerOffset;
    }

    /**
     * 判断是否与指定对象相等
     * 如果对象为同一卡片视图持有者，则认为相等
     */
    @Override
    public boolean equals(@Nullable Object other) {
        return Intrinsics.areEqual(this.cardViewHolder, other);
    }

    /**
     * 获取卡片视图持有者
     * @return 卡片视图持有者
     */
    @NotNull
    public final CardViewHolder<?> getCardViewHolder() {
        return this.cardViewHolder;
    }

    /**
     * 获取首次触摸点
     * @return 首次触摸点
     */
    @NotNull
    public final Point getFirstTouchPoint() {
        return this.firstTouchPoint;
    }

    /**
     * 获取所有关联的指针
     * @return 指针集合
     */
    @NotNull
    public final Set<Pointer> getPointers$cardstack_release() {
        return CollectionsKt.toSet(this.pointerSet);
    }

    /**
     * 获取主指针（第一个添加的指针）
     * @return 主指针，如果没有指针则返回null
     */
    @Nullable
    public final Pointer getPrimaryPointer$cardstack_release() {
        return (Pointer) CollectionsKt.firstOrNull(getPointers$cardstack_release());
    }

    /**
     * 获取主指针偏移量
     * @return 主指针偏移量
     */
    @NotNull
    public final Point getPrimaryPointerOffset$cardstack_release() {
        return this.primaryPointerOffset;
    }

    /**
     * 获取哈希码
     * @return 哈希码（基于卡片视图持有者）
     */
    @Override
    public int hashCode() {
        return this.cardViewHolder.hashCode();
    }

    /**
     * 判断是否为空选择（没有关联的指针）
     * @return 如果没有关联的指针则返回true
     */
    public final boolean isEmpty$cardstack_release() {
        return getPrimaryPointer$cardstack_release() == null;
    }

    /**
     * 移除指针
     * @param pointer 要移除的指针
     */
    public final void removePointer$cardstack_release(@NotNull Pointer pointer) {
        Intrinsics.checkNotNullParameter(pointer, "pointer");
        boolean isPrimaryPointer = Intrinsics.areEqual(getPrimaryPointer$cardstack_release(), pointer);
        this.pointerSet.remove(pointer);
        
        // 如果移除的是主指针，需要更新偏移量
        if (isPrimaryPointer) {
            if (getPrimaryPointer$cardstack_release() == null) {
                // 如果没有剩余指针，重置偏移量为零
                this.primaryPointerOffset = Point.Companion.getZero();
                return;
            }
            
            // 更新偏移量，基于新的主指针
            Pointer newPrimaryPointer = getPrimaryPointer$cardstack_release();
            if (newPrimaryPointer != null) {
                // 计算新的偏移量：原偏移量 + (被移除指针的位移 - 新主指针的位移)
                this.primaryPointerOffset = this.primaryPointerOffset.plus(
                    pointer.getDisplacement().minus(newPrimaryPointer.getDisplacement())
                );
            }
        }
    }

    /**
     * 设置主指针偏移量
     * @param offset 新的偏移量
     */
    public final void setPrimaryPointerOffset$cardstack_release(@NotNull Point offset) {
        Intrinsics.checkNotNullParameter(offset, "<set-?>");
        this.primaryPointerOffset = offset;
    }
}