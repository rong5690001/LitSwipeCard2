package com.rong.litswipecard.cardstack.cardgrid.selection;

import com.rong.litswipecard.cardstack.cardgrid.model.Point;
import com.rong.litswipecard.cardstack.cardgrid.selection.model.CardViewHolderSelection;
import com.rong.litswipecard.cardstack.cardgrid.swipe.model.Pointer;
import com.rong.litswipecard.cardstack.view.CardViewHolder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 卡片视图持有者选择器
 * 负责跟踪和管理卡片的选择状态
 */
public final class CardViewHolderSelector {

    /**
     * 卡片视图持有者查找器接口
     * 用于根据坐标查找对应的卡片视图持有者
     */
    public interface CardViewHolderFinder {
        /**
         * 根据位置查找卡片视图持有者
         * @param position 查找位置
         * @return 找到的卡片视图持有者，如果没有找到则返回null
         */
        @Nullable
        CardViewHolder<?> findCardViewHolder(@NotNull Point position);
    }

    /**
     * 卡片视图持有者查找器
     */
    private final CardViewHolderFinder cardViewHolderFinder;

    /**
     * 指针到卡片选择的映射
     */
    private final HashMap<Pointer, CardViewHolderSelection> selectionMap;

    /**
     * 构造函数
     * @param cardViewHolderFinder 卡片视图持有者查找器
     */
    public CardViewHolderSelector(@NotNull CardViewHolderFinder cardViewHolderFinder) {
        Intrinsics.checkNotNullParameter(cardViewHolderFinder, "cardViewHolderFinder");
        this.cardViewHolderFinder = cardViewHolderFinder;
        this.selectionMap = new HashMap<>();
    }

    /**
     * 获取所有已选择的卡片视图持有者
     * @return 已选择的卡片视图持有者集合
     */
    @NotNull
    public final Set<CardViewHolder<?>> getSelectedCardViewHolders() {
        Collection<CardViewHolderSelection> values = this.selectionMap.values();
        Intrinsics.checkNotNullExpressionValue(values, "selectionMap.values");
        Collection<CardViewHolderSelection> collection = values;
        ArrayList<CardViewHolder<?>> result = new ArrayList<>(CollectionsKt.collectionSizeOrDefault(collection, 10));
        Iterator<CardViewHolderSelection> it = collection.iterator();
        while (it.hasNext()) {
            result.add(it.next().getCardViewHolder());
        }
        return CollectionsKt.toSet(result);
    }

    /**
     * 选择指定指针对应的卡片
     * @param pointer 指针
     * @return 卡片选择对象，如果没有找到有效的卡片则返回null
     */
    @Nullable
    public final CardViewHolderSelection select(@NotNull Pointer pointer) {
        Intrinsics.checkNotNullParameter(pointer, "pointer");
        // 检查该指针是否已经有关联的选择
        if (this.selectionMap.containsKey(pointer)) {
            Object obj = this.selectionMap.get(pointer);
            Intrinsics.checkNotNull(obj);
            return (CardViewHolderSelection) obj;
        }
        
        // 根据指针位置查找卡片视图持有者
        CardViewHolder<?> findCardViewHolder = this.cardViewHolderFinder.findCardViewHolder(pointer.getOrigin());
        
        // 如果找不到或者卡片不可滑动，则返回null
        if (findCardViewHolder == null || !findCardViewHolder.isSwipable()) {
            return null;
        }
        
        // 检查该卡片是否已经被其他指针选中
        Collection<CardViewHolderSelection> values = this.selectionMap.values();
        Intrinsics.checkNotNullExpressionValue(values, "selectionMap.values");
        Iterator<CardViewHolderSelection> it = values.iterator();
        CardViewHolderSelection existingSelection = null;
        
        while (it.hasNext()) {
            CardViewHolderSelection selection = it.next();
            if (Intrinsics.areEqual(selection.getCardViewHolder(), findCardViewHolder)) {
                existingSelection = selection;
                break;
            }
        }
        
        // 如果已经有选择对象，则添加指针到现有选择
        if (existingSelection != null) {
            existingSelection.addPointer$cardstack_release(pointer);
            this.selectionMap.put(pointer, existingSelection);
            return existingSelection;
        }
        
        // 创建新的选择对象
        Point touchOffset = pointer.getOrigin().minus(new Point(findCardViewHolder.itemView.getX(), findCardViewHolder.itemView.getY()));
        CardViewHolderSelection newSelection = new CardViewHolderSelection(findCardViewHolder, touchOffset);
        newSelection.addPointer$cardstack_release(pointer);
        this.selectionMap.put(pointer, newSelection);
        return newSelection;
    }

    /**
     * 取消选择指定指针
     * @param pointer 指针
     * @return 被取消选择的卡片选择对象，如果指针没有关联的选择则返回null
     */
    @Nullable
    public final CardViewHolderSelection unselect(@NotNull Pointer pointer) {
        Intrinsics.checkNotNullParameter(pointer, "pointer");
        CardViewHolderSelection selection = this.selectionMap.get(pointer);
        if (selection == null) {
            return null;
        }
        selection.removePointer$cardstack_release(pointer);
        this.selectionMap.remove(pointer);
        return selection;
    }
}