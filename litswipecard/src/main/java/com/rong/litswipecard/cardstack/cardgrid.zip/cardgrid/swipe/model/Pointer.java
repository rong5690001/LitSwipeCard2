package com.rong.litswipecard.cardstack.cardgrid.swipe.model;

import com.rong.litswipecard.cardstack.cardgrid.model.Point;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 触摸指针模型类
 * 用于追踪和记录触摸事件的相关信息
 */
public final class Pointer {

    /**
     * 指针ID
     */
    private final int id;

    /**
     * 指针起始位置
     */
    private final Point origin;

    /**
     * 指针位移量
     */
    private final Point displacement;

    /**
     * 指针速度
     */
    private final Point velocity;

    /**
     * 构造函数
     * @param id 指针ID
     * @param origin 起始位置
     * @param displacement 位移量
     * @param velocity 速度
     */
    public Pointer(int id, @NotNull Point origin, @NotNull Point displacement, @Nullable Point velocity) {
        Intrinsics.checkNotNullParameter(origin, "origin");
        Intrinsics.checkNotNullParameter(displacement, "displacement");
        this.id = id;
        this.origin = origin;
        this.displacement = displacement;
        this.velocity = velocity;
    }

    /**
     * 提供带有默认参数的次级构造函数
     */
    public Pointer(int id, Point origin, Point displacement, Point velocity, int flags, DefaultConstructorMarker defaultConstructorMarker) {
        this(
            id, 
            (flags & 2) != 0 ? Point.Companion.getZero() : origin, 
            (flags & 4) != 0 ? Point.Companion.getZero() : displacement, 
            (flags & 8) != 0 ? null : velocity
        );
    }

    /**
     * 获取指针ID
     * @return 指针ID
     */
    public final int getId() {
        return this.id;
    }

    /**
     * 获取起始位置
     * @return 起始位置点
     */
    @NotNull
    public final Point getOrigin() {
        return this.origin;
    }

    /**
     * 获取位移量
     * @return 位移量点
     */
    @NotNull
    public final Point getDisplacement() {
        return this.displacement;
    }

    /**
     * 获取速度
     * @return 速度点，可能为null
     */
    @Nullable
    public final Point getVelocity() {
        return this.velocity;
    }

    /**
     * 复制指针，可修改部分属性
     * @param id 新的指针ID
     * @param origin 新的起始位置
     * @param displacement 新的位移量
     * @param velocity 新的速度
     * @return 新的指针对象
     */
    @NotNull
    public final Pointer copy(int id, @NotNull Point origin, @NotNull Point displacement, @Nullable Point velocity) {
        Intrinsics.checkNotNullParameter(origin, "origin");
        Intrinsics.checkNotNullParameter(displacement, "displacement");
        return new Pointer(id, origin, displacement, velocity);
    }

    /**
     * 便捷复制方法，支持部分参数默认值
     */
    public static Pointer copy$default(Pointer pointer, int id, Point origin, Point displacement, Point velocity, int flags, Object obj) {
        if ((flags & 1) != 0) {
            id = pointer.id;
        }
        if ((flags & 2) != 0) {
            origin = pointer.origin;
        }
        if ((flags & 4) != 0) {
            displacement = pointer.displacement;
        }
        if ((flags & 8) != 0) {
            velocity = pointer.velocity;
        }
        return pointer.copy(id, origin, displacement, velocity);
    }

    /**
     * 用于data class的component1方法
     */
    public final int component1() {
        return this.id;
    }

    /**
     * 用于data class的component2方法
     */
    @NotNull
    public final Point component2() {
        return this.origin;
    }

    /**
     * 用于data class的component3方法
     */
    @NotNull
    public final Point component3() {
        return this.displacement;
    }

    /**
     * 用于data class的component4方法
     */
    @Nullable
    public final Point component4() {
        return this.velocity;
    }

    /**
     * 指针相等性判断，基于指针ID
     */
    @Override
    public boolean equals(@Nullable Object other) {
        Pointer pointer = other instanceof Pointer ? (Pointer) other : null;
        return pointer != null && this.id == pointer.id;
    }

    /**
     * 哈希码基于指针ID
     */
    @Override
    public int hashCode() {
        return Integer.hashCode(this.id);
    }

    /**
     * 字符串表示形式
     */
    @NotNull
    @Override
    public String toString() {
        return "Pointer(id=" + this.id + ", origin=" + this.origin + ", displacement=" + this.displacement + ", velocity=" + this.velocity + ')';
    }
}