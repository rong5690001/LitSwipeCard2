package com.rong.litswipecard.cardstack.cardgrid.animation.model;

import android.view.View;
import com.rong.litswipecard.cardstack.cardgrid.model.Point;
import com.rong.litswipecard.cardstack.view.CardViewHolder;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 卡片属性数据类
 * 包含卡片的位置、尺寸和旋转角度等属性
 */
public final class CardProperty {

    /**
     * 静态伴生对象，提供创建CardProperty实例的工厂方法
     */
    @NotNull
    public static final Factory INSTANCE = new Factory();
    
    /**
     * 默认的卡片属性实例（零位置、零尺寸、零旋转）
     */
    private static final CardProperty DEFAULT = new CardProperty(Point.getZero(), 0.0f, 0.0f, 0.0f);

    /**
     * 卡片的位置（平移）
     */
    private final Point position;

    /**
     * 卡片的高度
     */
    private final float height;

    /**
     * 卡片的宽度
     */
    private final float width;

    /**
     * 卡片的旋转角度
     */
    private final float rotation;

    /**
     * 卡片属性工厂类
     * 提供创建CardProperty实例的便捷方法
     */
    public static final class Factory {
        /**
         * 从卡片视图持有者创建卡片属性
         * @param cardViewHolder 卡片视图持有者
         * @return 包含视图当前属性的卡片属性实例
         */
        @NotNull
        public final CardProperty fromCardViewHolder(@NotNull CardViewHolder<?> cardViewHolder) {
            View view = cardViewHolder.itemView;
            return new CardProperty(
                new Point(view.getTranslationX(), view.getTranslationY()),
                view.getHeight(),
                view.getWidth(),
                view.getRotation()
            );
        }

        /**
         * 获取默认的卡片属性实例
         * @return 默认卡片属性
         */
        @NotNull
        public final CardProperty getDefault() {
            return CardProperty.DEFAULT;
        }

        private Factory() {
            // 私有构造函数防止外部实例化
        }
    }

    /**
     * 构造函数
     * @param position 卡片位置
     * @param height 卡片高度
     * @param width 卡片宽度
     * @param rotation 卡片旋转角度
     */
    public CardProperty(@NotNull Point position, float height, float width, float rotation) {
        this.position = position;
        this.height = height;
        this.width = width;
        this.rotation = rotation;
    }

    /**
     * 创建卡片属性的副本，可以指定要更改的属性
     * @param position 新的位置，null表示保持原值
     * @param height 新的高度，负值表示保持原值
     * @param width 新的宽度，负值表示保持原值
     * @param rotation 新的旋转角度，负值表示保持原值
     * @return 新的卡片属性实例
     */
    @NotNull
    public final CardProperty copy(@NotNull Point position, float height, float width, float rotation) {
        return new CardProperty(position, height, width, rotation);
    }

    /**
     * 获取卡片位置
     * @return 卡片位置点
     */
    @NotNull
    public final Point getPosition() {
        return this.position;
    }

    /**
     * 获取卡片高度
     * @return 卡片高度
     */
    public final float getHeight() {
        return this.height;
    }

    /**
     * 获取卡片宽度
     * @return 卡片宽度
     */
    public final float getWidth() {
        return this.width;
    }

    /**
     * 获取卡片旋转角度
     * @return 卡片旋转角度
     */
    public final float getRotation() {
        return this.rotation;
    }

    /**
     * 比较两个卡片属性是否相等
     * @param other 要比较的对象
     * @return 如果相等则返回true，否则返回false
     */
    @Override
    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CardProperty)) {
            return false;
        }
        CardProperty otherProperty = (CardProperty) other;
        return this.position.equals(otherProperty.position) 
            && Float.compare(this.height, otherProperty.height) == 0 
            && Float.compare(this.width, otherProperty.width) == 0 
            && Float.compare(this.rotation, otherProperty.rotation) == 0;
    }

    /**
     * 计算卡片属性的哈希码
     * @return 哈希码
     */
    @Override
    public int hashCode() {
        return (((((this.position.hashCode() * 31) + Float.hashCode(this.height)) * 31) 
            + Float.hashCode(this.width)) * 31) + Float.hashCode(this.rotation);
    }

    /**
     * 将卡片属性转换为字符串表示
     * @return 字符串表示
     */
    @NotNull
    @Override
    public String toString() {
        return "CardProperty(position=" + this.position 
            + ", height=" + this.height 
            + ", width=" + this.width 
            + ", rotation=" + this.rotation + ')';
    }
}