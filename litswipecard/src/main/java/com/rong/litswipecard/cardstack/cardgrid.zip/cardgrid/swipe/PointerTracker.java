package com.rong.litswipecard.cardstack.cardgrid.swipe;

import android.view.MotionEvent;
import android.view.VelocityTracker;
import com.rong.litswipecard.cardstack.cardgrid.model.Point;
import com.rong.litswipecard.cardstack.cardgrid.swipe.model.Pointer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import timber.log.Timber;

/**
 * 指针跟踪器
 * 负责跟踪和管理触摸事件中的指针移动
 */
public final class PointerTracker {
    /**
     * 速度跟踪器的单位时间常量（毫秒）
     */
    private static final int VELOCITY_UNIT_TIME = 1000;

    /**
     * 事件监听器
     */
    private Listener listener;

    /**
     * 指针ID到指针对象的映射
     */
    private final HashMap<Integer, Pointer> pointerMap = new HashMap<>();

    /**
     * 速度跟踪器
     */
    private VelocityTracker velocityTracker;

    /**
     * 指针事件监听器接口
     */
    public interface Listener {
        /**
         * 指针按下事件回调
         * @param pointer 按下的指针
         */
        void onPointerDown(@NotNull Pointer pointer);

        /**
         * 指针移动事件回调
         * @param pointer 移动的指针
         */
        void onPointerMove(@NotNull Pointer pointer);

        /**
         * 指针抬起事件回调
         * @param pointer 抬起的指针
         */
        void onPointerUp(@NotNull Pointer pointer);
    }

    /**
     * 创建一个新的指针
     * @param pointerId 指针ID
     * @param origin 起始位置
     * @return 创建的指针对象
     */
    private Pointer createPointer(int pointerId, Point origin) {
        if (this.pointerMap.containsKey(Integer.valueOf(pointerId))) {
            throw new IllegalStateException(("Cannot add Pointer Id: " + pointerId + " has already been tracked").toString());
        }
        Pointer pointer = new Pointer(pointerId, origin, null, null, 12, null);
        this.pointerMap.put(Integer.valueOf(pointerId), pointer);
        return pointer;
    }

    /**
     * 获取指针的速度
     * @param pointerId 指针ID
     * @return 速度向量
     */
    private Point getVelocity(int pointerId) {
        VelocityTracker velocityTracker = this.velocityTracker;
        if (velocityTracker == null) {
            return new Point(0.0f, 0.0f);
        }
        velocityTracker.computeCurrentVelocity(VELOCITY_UNIT_TIME);
        return new Point(velocityTracker.getXVelocity(pointerId), velocityTracker.getYVelocity(pointerId));
    }

    /**
     * 更新指针位置
     * @param pointerId 指针ID
     * @param position 新位置
     * @return 更新后的指针对象
     */
    private Pointer updatePointerPosition(int pointerId, Point position) {
        Pointer pointer = this.pointerMap.get(Integer.valueOf(pointerId));
        if (pointer != null) {
            Pointer updatedPointer = Pointer.copy$default(pointer, 0, null, position.minus(pointer.getOrigin()), null, 11, null);
            this.pointerMap.put(Integer.valueOf(pointerId), updatedPointer);
            return updatedPointer;
        }
        Timber.e(new IllegalStateException("Cannot move Pointer Id: " + pointerId + " is not tracked"));
        return null;
    }

    /**
     * 移除指针
     * @param pointerId 指针ID
     * @return 带有速度信息的最终指针对象
     */
    private Pointer removePointer(int pointerId) {
        Pointer pointer = this.pointerMap.remove(Integer.valueOf(pointerId));
        if (pointer != null) {
            return Pointer.copy$default(pointer, 0, null, null, getVelocity(pointerId), 7, null);
        }
        Timber.e(new IllegalStateException("Cannot remove Pointer Id: " + pointerId + " is not tracked"));
        return null;
    }

    /**
     * 更新速度跟踪器
     * @param event 触摸事件
     */
    private void updateVelocityTracker(MotionEvent event) {
        if (this.velocityTracker == null) {
            this.velocityTracker = VelocityTracker.obtain();
        }
        VelocityTracker velocityTracker = this.velocityTracker;
        if (velocityTracker != null) {
            velocityTracker.addMovement(event);
        }
    }

    /**
     * 获取事件监听器
     * @return 事件监听器
     */
    @Nullable
    public final Listener getListener$cardstack_release() {
        return this.listener;
    }

    /**
     * 获取所有跟踪的指针
     * @return 指针集合
     */
    @NotNull
    public final Set<Pointer> getPointers$cardstack_release() {
        Collection<Pointer> values = this.pointerMap.values();
        Intrinsics.checkNotNullExpressionValue(values, "pointerMap.values");
        return CollectionsKt.toSet(values);
    }

    /**
     * 释放资源
     */
    public final void release$cardstack_release() {
        this.pointerMap.clear();
        VelocityTracker velocityTracker = this.velocityTracker;
        if (velocityTracker != null) {
            velocityTracker.recycle();
        }
        this.velocityTracker = null;
    }

    /**
     * 设置事件监听器
     * @param listener 事件监听器
     */
    public final void setListener$cardstack_release(@Nullable Listener listener) {
        this.listener = listener;
    }

    /**
     * 跟踪触摸事件
     * @param event 触摸事件
     */
    public final void track$cardstack_release(@NotNull MotionEvent event) {
        Intrinsics.checkNotNullParameter(event, "event");
        int actionMasked = event.getActionMasked();
        
        // 如果是ACTION_DOWN，重置状态
        if (actionMasked == MotionEvent.ACTION_DOWN) {
            release$cardstack_release();
        }
        
        // 更新速度跟踪器
        updateVelocityTracker(event);
        
        int actionIndex = event.getActionIndex();
        int pointerId = event.getPointerId(actionIndex);
        
        // 处理各种触摸事件类型
        if (actionMasked == MotionEvent.ACTION_DOWN) {
            // 按下事件
            Pointer pointer = createPointer(pointerId, new Point(event.getX(actionIndex), event.getY(actionIndex)));
            Listener listener = this.listener;
            if (listener != null) {
                listener.onPointerDown(pointer);
            }
        } 
        else if (actionMasked == MotionEvent.ACTION_MOVE) {
            // 移动事件
            int pointerCount = event.getPointerCount();
            for (int i = 0; i < pointerCount; i++) {
                Pointer pointer = updatePointerPosition(event.getPointerId(i), new Point(event.getX(i), event.getY(i)));
                if (pointer != null && this.listener != null) {
                    this.listener.onPointerMove(pointer);
                }
            }
        } 
        else if (actionMasked == MotionEvent.ACTION_UP || 
                 actionMasked == MotionEvent.ACTION_CANCEL || 
                 actionMasked == MotionEvent.ACTION_POINTER_UP) {
            // 抬起事件
            Pointer pointer = removePointer(pointerId);
            if (pointer != null && this.listener != null) {
                this.listener.onPointerUp(pointer);
            }
        }
    }
}