package com.rong.litswipecard.cardstack.cardgrid.view;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0000\u0018\u00002\u00020\u0001:\u0001\u0005B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0005\u0010\u0006J\r\u0010\u0007\u001a\u00020\u0004¢\u0006\u0004\b\u0007\u0010\u0006J\r\u0010\t\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\u0015\u0010\r\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\u0004¢\u0006\u0004\b\r\u0010\u000eR\u0016\u0010\u0010\u001a\u00020\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0005\u0010\u000fR\u0014\u0010\u0014\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010\u0013R\u0014\u0010\u0016\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010\u0013¨\u0006\u0017"}, d2 = {"Lcom/tinder/cardstack/cardgrid/view/ScrollVelocityTracker;", "", "<init>", "()V", "", "a", "()F", "getVelocity", "", "getLastUpdateTimestamp", "()J", "scrollOffset", "", "track", "(F)V", "F", "velocity", "Lcom/tinder/cardstack/cardgrid/view/ScrollVelocityTracker$a;", "b", "Lcom/tinder/cardstack/cardgrid/view/ScrollVelocityTracker$a;", "scrollOffsetUpdate", "c", "previousScrollOffsetUpdate", "cardstack_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* loaded from: classes7.dex */
public final class ScrollVelocityTracker {

    private float velocity;
    private final ScrollUpdate currentUpdate = new ScrollUpdate(0.0f, 0, 3, null);
    private final ScrollUpdate previousUpdate = new ScrollUpdate(0.0f, 0, 3, null);

    private static final class ScrollUpdate {
        private float offset;
        private long timestamp;

        public ScrollUpdate(float offset, long timestamp) {
            this.offset = offset;
            this.timestamp = timestamp;
        }

        public final float getOffset() {
            return this.offset;
        }

        public final long getTimestamp() {
            return this.timestamp;
        }

        public final void setOffset(float offset) {
            this.offset = offset;
        }

        public final void setTimestamp(long timestamp) {
            this.timestamp = timestamp;
        }

        public /* synthetic */ ScrollUpdate(float offset, long timestamp, int flags, DefaultConstructorMarker defaultConstructorMarker) {
            this((flags & 1) != 0 ? 0.0f : offset, (flags & 2) != 0 ? 0L : timestamp);
        }
    }

    private final float calculateVelocity() {
        float offsetDifference = this.currentUpdate.getOffset() - this.previousUpdate.getOffset();
        float timeDifferenceInSeconds = (this.currentUpdate.getTimestamp() - this.previousUpdate.getTimestamp()) / 1000.0f;
        if (timeDifferenceInSeconds == 0.0f) {
            return 0.0f;
        }
        return offsetDifference / timeDifferenceInSeconds;
    }

    public final long getLastUpdateTimestamp() {
        return this.currentUpdate.getTimestamp();
    }

    public final float getVelocity() {
        return this.velocity;
    }

    public final void track(float scrollOffset) {
        this.previousUpdate.setOffset(this.currentUpdate.getOffset());
        this.previousUpdate.setTimestamp(this.currentUpdate.getTimestamp());
        this.currentUpdate.setOffset(scrollOffset);
        this.currentUpdate.setTimestamp(System.currentTimeMillis());
        this.velocity = calculateVelocity();
    }
}