package com.rong.litswipecard.cardstack.cardgrid.animation.animator;

import android.animation.ValueAnimator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import com.google.android.gms.measurement.api.AppMeasurementSdk;
import com.rong.litswipecard.cardstack.cardgrid.animation.model.CardProperty;
import com.rong.litswipecard.cardstack.cardgrid.animation.model.CardPropertyAnimation;
import com.rong.litswipecard.cardstack.cardgrid.model.Point;
import com.rong.litswipecard.cardstack.view.CardViewHolder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.coroutines.debug.internal.DebugCoroutineInfoImplKt;
import org.jetbrains.annotations.NotNull;

/**
 * 卡片属性动画器
 * 负责控制和管理卡片动画的属性变化
 */
@Metadata(d1 = {"\u0000f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010!\n\u0002\b\u0007\b\u0000\u0018\u0000 B2\u00020\u0001:\u0004'BCDB\u0013\u0012\n\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u0017\u0010\t\u001a\u00020\b2\u0006\u0010\u0007\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\t\u0010\nJ\u000f\u0010\u000b\u001a\u00020\bH\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u001d\u0010\u0010\u001a\u00020\b2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\r¢\u0006\u0004\b\u0010\u0010\u0011J%\u0010\u0014\u001a\u00020\b2\u0006\u0010\u000f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u0013\u001a\u00020\u0012¢\u0006\u0004\b\u0014\u0010\u0015J\u0017\u0010\u0017\u001a\u00020\b2\b\b\u0002\u0010\u0016\u001a\u00020\r¢\u0006\u0004\b\u0017\u0010\u0018J\u001d\u0010\u0017\u001a\u00020\b2\u0006\u0010\u0019\u001a\u00020\r2\u0006\u0010\u0016\u001a\u00020\r¢\u0006\u0004\b\u0017\u0010\u0011J\u001d\u0010\u001a\u001a\u00020\b2\u0006\u0010\u0019\u001a\u00020\r2\u0006\u0010\u0016\u001a\u00020\r¢\u0006\u0004\b\u001a\u0010\u0011J\r\u0010\u001b\u001a\u00020\b¢\u0006\u0004\b\u001b\u0010\fJ\r\u0010\u001d\u001a\u00020\u001c¢\u0006\u0004\b\u001d\u0010\u001eJ\u0015\u0010!\u001a\u00020\b2\u0006\u0010 \u001a\u00020\u001f¢\u0006\u0004\b!\u0010\"J\u000f\u0010&\u001a\u00020#H\u0000¢\u0006\u0004\b$\u0010%R\u001b\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u00028\u0006¢\u0006\f\n\u0004\b'\u0010(\u001a\u0004\b)\u0010*R\"\u0010/\u001a\u00020\u00068\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u000b\u0010+\u001a\u0004\b,\u0010-\"\u0004\b.\u0010\nR$\u00104\u001a\u0002002\u0006\u00101\u001a\u0002008\u0002@BX\u0082\u000e¢\u0006\f\n\u0004\b\t\u00102\"\u0004\b'\u00103R\u0016\u00108\u001a\u0002058\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b6\u00107R\u001c\u0010=\u001a\n :*\u0004\u0018\u000109098\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b;\u0010<R\u001a\u0010A\u001a\b\u0012\u0004\u0012\u00020\u001f0>8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b?\u0010@¨\u0006E"}, d2 = {"Lcom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator;", "", "Lcom/tinder/cardstack/view/CardViewHolder;", "cardViewHolder", "<init>", "(Lcom/tinder/cardstack/view/CardViewHolder;)V", "Lcom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator$State;", "newState", "", "c", "(Lcom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator$State;)V", "b", "()V", "Lcom/tinder/cardstack/cardgrid/model/Point;", "firstTouchPoint", "delta", "move", "(Lcom/tinder/cardstack/cardgrid/model/Point;Lcom/tinder/cardstack/cardgrid/model/Point;)V", "", TypedValues.TransitionType.S_DURATION, "swipe", "(Lcom/tinder/cardstack/cardgrid/model/Point;Lcom/tinder/cardstack/cardgrid/model/Point;J)V", "endPosition", "recover", "(Lcom/tinder/cardstack/cardgrid/model/Point;)V", "fromPosition", "translate", "stop", "Lcom/tinder/cardstack/cardgrid/animation/model/CardPropertyAnimation;", "getCardAnimation", "()Lcom/tinder/cardstack/cardgrid/animation/model/CardPropertyAnimation;", "Lcom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator$OnCompleteListener;", "onCompleteListener", "addOnCompleteListener", "(Lcom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator$OnCompleteListener;)V", "Lcom/tinder/cardstack/cardgrid/animation/model/CardProperty;", "updateAndGetCurrentValue$cardstack_release", "()Lcom/tinder/cardstack/cardgrid/animation/model/CardProperty;", "updateAndGetCurrentValue", "a", "Lcom/tinder/cardstack/view/CardViewHolder;", "getCardViewHolder", "()Lcom/tinder/cardstack/view/CardViewHolder;", "Lcom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator$State;", "getState$cardstack_release", "()Lcom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator$State;", "setState$cardstack_release", "state", "Lcom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator$a;", AppMeasurementSdk.ConditionalUserProperty.VALUE, "Lcom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator$a;", "(Lcom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator$a;)V", "animationConfig", "", "d", "Z", "shouldStartNewAnimation", "Landroid/animation/ValueAnimator;", "kotlin.jvm.PlatformType", "e", "Landroid/animation/ValueAnimator;", "valueAnimator", "", "f", "Ljava/util/List;", "onCompleteListeners", "Companion", "OnCompleteListener", "State", "cardstack_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nCardPropertyAnimator.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CardPropertyAnimator.kt\ncom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,170:1\n1855#2,2:171\n*S KotlinDebug\n*F\n+ 1 CardPropertyAnimator.kt\ncom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator\n*L\n127#1:171,2\n*E\n"})
/* loaded from: classes7.dex */
public final class CardPropertyAnimator {
    private static final long DEFAULT_DURATION = 180;         // 默认动画持续时间
    private static final long MAX_SWIPE_DURATION = 1000;      // 最大滑动动画持续时间
    private static final long MIN_SWIPE_DURATION = 500;       // 最小滑动动画持续时间
    private static final long RECOVER_DURATION = 250;         // 恢复动画持续时间
    private static final long TRANSLATE_DURATION = 250;       // 平移动画持续时间
    private static final AccelerateInterpolator ACCELERATE_INTERPOLATOR = new AccelerateInterpolator(); // 加速插值器
    private static final CardPropertyAnimation.Default DEFAULT_ANIMATION = new CardPropertyAnimation.Default(); // 默认动画

    /* renamed from: a, reason: from kotlin metadata */
    private final CardViewHolder cardViewHolder;

    /* renamed from: b, reason: from kotlin metadata */
    private State state = State.STOPPED;

    /* renamed from: c, reason: from kotlin metadata */
    private AnimationConfig animationConfig;

    /* renamed from: d, reason: from kotlin metadata */
    private boolean shouldStartNewAnimation;

    /* renamed from: e, reason: from kotlin metadata */
    private final ValueAnimator valueAnimator;

    /* renamed from: f, reason: from kotlin metadata */
    private final List<OnCompleteListener> onCompleteListeners;

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\b`\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&¨\u0006\u0004"}, d2 = {"Lcom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator$OnCompleteListener;", "", "onComplete", "", "cardstack_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public interface OnCompleteListener {
        /**
         * 动画完成时调用
         */
        void onComplete();
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0080\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004¨\u0006\u0005"}, d2 = {"Lcom/tinder/cardstack/cardgrid/animation/animator/CardPropertyAnimator$State;", "", "(Ljava/lang/String;I)V", DebugCoroutineInfoImplKt.RUNNING, "STOPPED", "cardstack_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public enum State {
        /**
         * 运行中状态
         */
        RUNNING,
        
        /**
         * 已停止状态
         */
        STOPPED
    }

    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[State.values().length];
            try {
                iArr[State.STOPPED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[State.RUNNING.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /**
     * 构造函数
     * @param cardViewHolder 卡片视图持有者
     */
    public CardPropertyAnimator(@NotNull CardViewHolder<?> cardViewHolder) {
        Intrinsics.checkNotNullParameter(cardViewHolder, "cardViewHolder");
        this.cardViewHolder = cardViewHolder;
        this.animationConfig = new AnimationConfig(null, 0L, null);
        this.valueAnimator = ValueAnimator.ofFloat(0.0f, 1.0f);
        this.onCompleteListeners = new ArrayList<>();
    }

    /**
     * 设置动画配置
     * @param config 动画配置
     */
    private void setAnimationConfig(AnimationConfig config) {
        if (this.animationConfig.equals(config)) {
            return;
        }
        this.shouldStartNewAnimation = true;
        this.animationConfig = config;
    }

    /**
     * 开始动画
     */
    private void startAnimation() {
        this.valueAnimator.setInterpolator(this.animationConfig.getInterpolator());
        this.valueAnimator.setDuration(this.animationConfig.getDuration());
        this.valueAnimator.cancel();
        this.valueAnimator.start();
    }

    /**
     * 更改动画状态
     * @param newState 新状态
     */
    private void changeState(State newState) {
        if (this.state == newState) {
            return;
        }
        this.state = newState;
        if (WhenMappings.$EnumSwitchMapping$0[newState.ordinal()] != 1) {
            return;
        }
        this.valueAnimator.cancel();
        Iterator it2 = this.onCompleteListeners.iterator();
        while (it2.hasNext()) {
            ((OnCompleteListener) it2.next()).onComplete();
        }
        this.onCompleteListeners.clear();
    }

    public static /* synthetic */ void recover$default(CardPropertyAnimator cardPropertyAnimator, Point point, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            point = Point.INSTANCE.getZero();
        }
        cardPropertyAnimator.recover(point);
    }

    /**
     * 添加动画完成监听器
     * @param onCompleteListener 动画完成监听器
     */
    public final void addOnCompleteListener(@NotNull OnCompleteListener onCompleteListener) {
        Intrinsics.checkNotNullParameter(onCompleteListener, "onCompleteListener");
        this.onCompleteListeners.add(onCompleteListener);
    }

    /**
     * 获取卡片动画
     * @return 卡片属性动画
     */
    @NotNull
    public final CardPropertyAnimation getCardAnimation() {
        return this.animationConfig.getCardAnimation();
    }

    /**
     * 获取卡片视图持有者
     * @return 卡片视图持有者
     */
    @NotNull
    public final CardViewHolder<?> getCardViewHolder() {
        return this.cardViewHolder;
    }

    /**
     * 获取动画状态
     * @return 动画状态
     */
    @NotNull
    public final State getState() {
        return this.state;
    }

    /**
     * 移动卡片
     * @param firstTouchPoint 首次触摸点
     * @param delta 移动距离
     */
    public final void move(@NotNull Point firstTouchPoint, @NotNull Point delta) {
        Intrinsics.checkNotNullParameter(firstTouchPoint, "firstTouchPoint");
        Intrinsics.checkNotNullParameter(delta, "delta");
        setAnimationConfig(new AnimationConfig(
            new CardPropertyAnimation.Move(
                CardProperty.INSTANCE.fromCardViewHolder(this.cardViewHolder),
                firstTouchPoint,
                delta
            ),
            0L,
            null
        ));
    }

    /**
     * 恢复卡片位置
     * @param endPosition 结束位置
     */
    public final void recover(@NotNull Point endPosition) {
        Intrinsics.checkNotNullParameter(endPosition, "endPosition");
        setAnimationConfig(new AnimationConfig(
            new CardPropertyAnimation.Recover(
                CardProperty.INSTANCE.fromCardViewHolder(this.cardViewHolder),
                endPosition,
                0.0f
            ),
            RECOVER_DURATION,
            null
        ));
    }

    /**
     * 恢复卡片位置（默认到零位置）
     */
    public final void recover() {
        recover(Point.getZero());
    }

    /**
     * 从指定位置恢复到指定位置
     * @param fromPosition 起始位置
     * @param endPosition 结束位置
     */
    public final void recover(@NotNull Point fromPosition, @NotNull Point endPosition) {
        Intrinsics.checkNotNullParameter(fromPosition, "fromPosition");
        Intrinsics.checkNotNullParameter(endPosition, "endPosition");
        setAnimationConfig(new AnimationConfig(
            new CardPropertyAnimation.Recover(
                CardProperty.copy$default(
                    CardProperty.INSTANCE.fromCardViewHolder(this.cardViewHolder),
                    fromPosition,
                    0.0f,
                    0.0f,
                    0.0f,
                    14,
                    null
                ),
                endPosition,
                0.0f
            ),
            RECOVER_DURATION,
            null
        ));
    }

    /**
     * 停止动画
     */
    public final void stop() {
        changeState(State.STOPPED);
    }

    /**
     * 滑动卡片
     * @param delta 滑动距离
     * @param firstTouchPoint 首次触摸点
     * @param duration 动画持续时间
     */
    public final void swipe(@NotNull Point delta, @NotNull Point firstTouchPoint, long duration) {
        Intrinsics.checkNotNullParameter(delta, "delta");
        Intrinsics.checkNotNullParameter(firstTouchPoint, "firstTouchPoint");
        CardProperty fromCardViewHolder = CardProperty.INSTANCE.fromCardViewHolder(this.cardViewHolder);
        setAnimationConfig(new AnimationConfig(
            new CardPropertyAnimation.Swipe(
                fromCardViewHolder,
                fromCardViewHolder.getPosition().plus(delta),
                firstTouchPoint
            ),
            Math.max(Math.min(MAX_SWIPE_DURATION, duration), MIN_SWIPE_DURATION),
            new LinearInterpolator()
        ));
    }

    /**
     * 平移卡片
     * @param fromPosition 起始位置
     * @param endPosition 结束位置
     */
    public final void translate(@NotNull Point fromPosition, @NotNull Point endPosition) {
        Intrinsics.checkNotNullParameter(fromPosition, "fromPosition");
        Intrinsics.checkNotNullParameter(endPosition, "endPosition");
        setAnimationConfig(new AnimationConfig(
            new CardPropertyAnimation.Translate(
                CardProperty.copy$default(
                    CardProperty.INSTANCE.fromCardViewHolder(this.cardViewHolder),
                    fromPosition,
                    0.0f,
                    0.0f,
                    0.0f,
                    14,
                    null
                ),
                endPosition,
                0.0f
            ),
            TRANSLATE_DURATION,
            new LinearInterpolator()
        ));
    }

    /**
     * 更新并获取当前卡片属性值
     * @return 当前卡片属性
     */
    @NotNull
    public final CardProperty updateAndGetCurrentValue() {
        if (this.shouldStartNewAnimation) {
            startAnimation();
            this.shouldStartNewAnimation = false;
        }
        if (this.valueAnimator.isStarted() || this.valueAnimator.isRunning()) {
            changeState(State.RUNNING);
        } else {
            changeState(State.STOPPED);
        }
        return this.animationConfig.getCardAnimation().getValue(this.valueAnimator.getAnimatedFraction());
    }

    /**
     * 动画配置类
     * 封装动画类型、持续时间和插值器
     */
    private static final class AnimationConfig {
        private final CardPropertyAnimation cardAnimation;
        private final long duration;
        private final Interpolator interpolator;

        /**
         * 构造函数
         * @param cardAnimation 卡片属性动画
         * @param duration 持续时间
         * @param interpolator 插值器
         */
        public AnimationConfig(CardPropertyAnimation cardAnimation, long duration, Interpolator interpolator) {
            this.cardAnimation = cardAnimation != null ? cardAnimation : DEFAULT_ANIMATION;
            this.duration = duration > 0 ? duration : DEFAULT_DURATION;
            this.interpolator = interpolator != null ? interpolator : ACCELERATE_INTERPOLATOR;
        }

        /**
         * 获取卡片属性动画
         * @return 卡片属性动画
         */
        public CardPropertyAnimation getCardAnimation() {
            return this.cardAnimation;
        }

        /**
         * 获取动画持续时间
         * @return 动画持续时间
         */
        public long getDuration() {
            return this.duration;
        }

        /**
         * 获取插值器
         * @return 插值器
         */
        public Interpolator getInterpolator() {
            return this.interpolator;
        }

        /**
         * 判断两个动画配置是否相等
         * @param obj 要比较的对象
         * @return 如果相等则返回true，否则返回false
         */
        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof AnimationConfig)) {
                return false;
            }
            AnimationConfig other = (AnimationConfig) obj;
            return this.cardAnimation.equals(other.cardAnimation) 
                && this.duration == other.duration 
                && this.interpolator.equals(other.interpolator);
        }

        /**
         * 计算哈希码
         * @return 哈希码
         */
        @Override
        public int hashCode() {
            return ((this.cardAnimation.hashCode() * 31) + Long.hashCode(this.duration)) * 31 + this.interpolator.hashCode();
        }

        /**
         * 转换为字符串表示
         * @return 字符串表示
         */
        @Override
        public String toString() {
            return "AnimationConfig(cardAnimation=" + this.cardAnimation 
                + ", duration=" + this.duration 
                + ", interpolator=" + this.interpolator + ")";
        }
    }
}