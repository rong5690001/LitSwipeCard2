package com.rong.litswipecard.cardstack.cardgrid.animation;

import com.rong.litswipecard.cardstack.cardgrid.animation.animator.CardPropertyAnimator;
import com.rong.litswipecard.cardstack.cardgrid.animation.model.CardProperty;
import com.rong.litswipecard.cardstack.view.CardViewHolder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 卡片动画引擎
 * 负责管理和协调卡片的属性动画
 */
@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\b\u0005\b\u0000\u0018\u00002\u00020\u0001:\u0002\u00050B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0005\u0010\u0003J\u001b\u0010\u000b\u001a\u00020\b2\n\u0010\u0007\u001a\u0006\u0012\u0002\b\u00030\u0006H\u0000¢\u0006\u0004\b\t\u0010\nJ\u001b\u0010\u000e\u001a\u00020\u00042\n\u0010\u0007\u001a\u0006\u0012\u0002\b\u00030\u0006H\u0000¢\u0006\u0004\b\f\u0010\rJ\u000f\u0010\u0010\u001a\u00020\u0004H\u0000¢\u0006\u0004\b\u000f\u0010\u0003J\u000f\u0010\u0012\u001a\u00020\u0004H\u0000¢\u0006\u0004\b\u0011\u0010\u0003J\u000f\u0010\u0014\u001a\u00020\u0004H\u0000¢\u0006\u0004\b\u0013\u0010\u0003J\u0017\u0010\u0019\u001a\u00020\u00162\u0006\u0010\u0015\u001a\u00020\bH\u0000¢\u0006\u0004\b\u0017\u0010\u0018R$\u0010 \u001a\u0004\u0018\u00010\u001a8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0005\u0010\u001b\u001a\u0004\b\u001c\u0010\u001d\"\u0004\b\u001e\u0010\u001fR\u0018\u0010$\u001a\u00060!R\u00020\u00008\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\"\u0010#R6\u0010+\u001a\u001e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\u00160%j\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\u0016`&8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b'\u0010(\u001a\u0004\b)\u0010*R\u001a\u0010/\u001a\b\u0012\u0004\u0012\u00020\b0,8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b-\u0010.¨\u00061"}, d2 = {"Lcom/rong/litswipecard/cardstack/cardgrid/animation/CardAnimationEngine;", "", "<init>", "()V", "", "a", "Lcom/rong/litswipecard/cardstack/view/CardViewHolder;", "cardViewHolder", "Lcom/rong/litswipecard/cardstack/cardgrid/animation/animator/CardPropertyAnimator;", "animate$cardstack_release", "(Lcom/rong/litswipecard/cardstack/view/CardViewHolder;)Lcom/rong/litswipecard/cardstack/cardgrid/animation/animator/CardPropertyAnimator;", "animate", "reset$cardstack_release", "(Lcom/rong/litswipecard/cardstack/view/CardViewHolder;)V", "reset", "resetAll$cardstack_release", "resetAll", "onUpdate$cardstack_release", "onUpdate", "onPostUpdate$cardstack_release", "onPostUpdate", "animator", "Lcom/rong/litswipecard/cardstack/cardgrid/animation/model/CardProperty;", "getCardProperty$cardstack_release", "(Lcom/rong/litswipecard/cardstack/cardgrid/animation/animator/CardPropertyAnimator;)Lcom/rong/litswipecard/cardstack/cardgrid/animation/model/CardProperty;", "getCardProperty", "Lcom/rong/litswipecard/cardstack/cardgrid/animation/CardAnimationEngine$Renderer;", "Lcom/rong/litswipecard/cardstack/cardgrid/animation/CardAnimationEngine$Renderer;", "getRenderer$cardstack_release", "()Lcom/rong/litswipecard/cardstack/cardgrid/animation/CardAnimationEngine$Renderer;", "setRenderer$cardstack_release", "(Lcom/rong/litswipecard/cardstack/cardgrid/animation/CardAnimationEngine$Renderer;)V", "renderer", "Lcom/rong/litswipecard/cardstack/cardgrid/animation/CardAnimationEngine$a;", "b", "Lcom/rong/litswipecard/cardstack/cardgrid/animation/CardAnimationEngine$a;", "animatorPool", "Ljava/util/HashMap;", "Lkotlin/collections/HashMap;", "c", "Ljava/util/HashMap;", "getTempCardProperties$cardstack_release", "()Ljava/util/HashMap;", "tempCardProperties", "", "getActiveAnimators$cardstack_release", "()Ljava/util/List;", "activeAnimators", "Renderer", "cardstack_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nCardAnimationEngine.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CardAnimationEngine.kt\ncom/rong/litswipecard/cardstack/cardgrid/animation/CardAnimationEngine\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,102:1\n1855#2,2:103\n766#2:105\n857#2,2:106\n1855#2,2:108\n*S KotlinDebug\n*F\n+ 1 CardAnimationEngine.kt\ncom/rong/litswipecard/cardstack/cardgrid/animation/CardAnimationEngine\n*L\n37#1:103,2\n65#1:105\n65#1:106,2\n68#1:108,2\n*E\n"})
/* loaded from: classes7.dex */
public final class CardAnimationEngine {

    /**
     * 动画渲染器，负责将动画属性应用到视图上
     */
    private Renderer renderer;

    /**
     * 动画器对象池，管理所有卡片的动画器实例
     */
    private final AnimatorPool animatorPool = new AnimatorPool();

    /**
     * 临时存储卡片属性的映射表
     */
    private final HashMap<CardPropertyAnimator, CardProperty> tempCardProperties = new HashMap<>();

    /**
     * 渲染器接口
     * 负责将卡片属性渲染到实际视图上
     */
    public interface Renderer {
        /**
         * 渲染卡片属性到视图
         * @param cardViewHolder 卡片视图持有者
         * @param cardProperty 卡片属性
         */
        void render(@NotNull CardViewHolder<?> cardViewHolder, @NotNull CardProperty cardProperty);

        /**
         * 请求更新视图
         */
        void requestUpdate();
    }

    /**
     * 动画器对象池
     * 管理卡片与动画器之间的映射关系
     */
    private final class AnimatorPool {
        private final HashMap<CardViewHolder, CardPropertyAnimator> animatorMap = new HashMap<>();

        /**
         * 获取所有活跃的动画器
         * @return 动画器列表
         */
        public final List<CardPropertyAnimator> getActiveAnimators() {
            Collection<CardPropertyAnimator> values = this.animatorMap.values();
            return new ArrayList<>(values);
        }

        /**
         * 获取或创建指定卡片的动画器
         * @param cardViewHolder 卡片视图持有者
         * @return 关联的动画器
         */
        public final CardPropertyAnimator getOrCreateAnimator(CardViewHolder cardViewHolder) {
            if (this.animatorMap.containsKey(cardViewHolder)) {
                return this.animatorMap.get(cardViewHolder);
            }
            CardPropertyAnimator cardPropertyAnimator = new CardPropertyAnimator(cardViewHolder);
            this.animatorMap.put(cardViewHolder, cardPropertyAnimator);
            return cardPropertyAnimator;
        }

        /**
         * 移除指定的动画器
         * @param cardPropertyAnimator 要移除的动画器
         */
        public final void removeAnimator(CardPropertyAnimator cardPropertyAnimator) {
            this.animatorMap.remove(cardPropertyAnimator.getCardViewHolder());
        }

        /**
         * 移除指定卡片的动画器
         * @param cardViewHolder 卡片视图持有者
         */
        public final void removeAnimator(CardViewHolder cardViewHolder) {
            this.animatorMap.remove(cardViewHolder);
        }
    }

    /**
     * 清理已停止的动画器
     */
    private final void cleanStoppedAnimators() {
        List<CardPropertyAnimator> allAnimators = this.animatorPool.getActiveAnimators();
        ArrayList<CardPropertyAnimator> stoppedAnimators = new ArrayList<>();
        
        // 找出所有已停止的动画器
        for (CardPropertyAnimator animator : allAnimators) {
            if (animator.getState() == CardPropertyAnimator.State.STOPPED) {
                stoppedAnimators.add(animator);
            }
        }
        
        // 移除已停止的动画器
        for (CardPropertyAnimator animator : stoppedAnimators) {
            this.animatorPool.removeAnimator(animator);
        }
    }

    /**
     * 为指定卡片创建动画
     * @param cardViewHolder 卡片视图持有者
     * @return 卡片属性动画器
     */
    @NotNull
    public final CardPropertyAnimator animate(@NotNull CardViewHolder<?> cardViewHolder) {
        CardPropertyAnimator animator = this.animatorPool.getOrCreateAnimator(cardViewHolder);
        Renderer renderer = this.renderer;
        if (renderer != null) {
            renderer.requestUpdate();
        }
        return animator;
    }

    /**
     * 获取所有活跃的动画器
     * @return 动画器列表
     */
    @NotNull
    public final List<CardPropertyAnimator> getActiveAnimators() {
        return this.animatorPool.getActiveAnimators();
    }

    /**
     * 获取指定动画器的卡片属性
     * @param animator 动画器
     * @return 关联的卡片属性
     */
    @NotNull
    public final CardProperty getCardProperty(@NotNull CardPropertyAnimator animator) {
        return this.tempCardProperties.get(animator);
    }

    /**
     * 获取渲染器
     * @return 当前使用的渲染器
     */
    @Nullable
    public final Renderer getRenderer() {
        return this.renderer;
    }

    /**
     * 获取临时卡片属性映射表
     * @return 卡片属性映射表
     */
    @NotNull
    public final HashMap<CardPropertyAnimator, CardProperty> getTempCardProperties() {
        return this.tempCardProperties;
    }

    /**
     * 更新后处理
     * 清理临时数据并触发新的更新请求
     */
    public final void onPostUpdate() {
        this.tempCardProperties.clear();
        if (!this.animatorPool.getActiveAnimators().isEmpty() && this.renderer != null) {
            this.renderer.requestUpdate();
        }
        cleanStoppedAnimators();
    }

    /**
     * 执行动画更新
     * 计算当前属性值并调用渲染器
     */
    public final void onUpdate() {
        Renderer renderer = this.renderer;
        if (renderer == null) {
            return;
        }
        for (CardPropertyAnimator animator : this.animatorPool.getActiveAnimators()) {
            CardProperty currentValue = animator.updateAndGetCurrentValue();
            this.tempCardProperties.put(animator, currentValue);
            renderer.render(animator.getCardViewHolder(), currentValue);
        }
    }

    /**
     * 重置指定卡片的动画
     * @param cardViewHolder 卡片视图持有者
     */
    public final void reset(@NotNull CardViewHolder<?> cardViewHolder) {
        this.animatorPool.getOrCreateAnimator(cardViewHolder).stop();
        this.animatorPool.removeAnimator(cardViewHolder);
        Renderer renderer = this.renderer;
        if (renderer != null) {
            renderer.render(cardViewHolder, CardProperty.getDefault());
        }
    }

    /**
     * 重置所有动画
     */
    public final void resetAll() {
        for (CardPropertyAnimator animator : getActiveAnimators()) {
            reset(animator.getCardViewHolder());
        }
    }

    /**
     * 设置渲染器
     * @param renderer 要使用的渲染器
     */
    public final void setRenderer(@Nullable Renderer renderer) {
        this.renderer = renderer;
    }
}