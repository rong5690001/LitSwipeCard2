package com.rong.litswipecard.cardstack.cardgrid.model;

import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 二维平面上的点类
 * 用于表示卡片的位置、移动等坐标相关计算
 */
public final class Point {

    /**
     * 零点常量，表示坐标原点(0,0)
     */
    @NotNull
    public static final Companion Companion = new Companion(null);
    private static final Point ZERO_POINT = new Point(0.0f, 0.0f);

    /**
     * x轴坐标
     */
    private final float x;

    /**
     * y轴坐标
     */
    private final float y;

    /**
     * 伴生对象，提供静态方法和常量
     */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        /**
         * 获取零点坐标(0,0)
         * @return 零点对象
         */
        @NotNull
        public final Point getZero() {
            return Point.ZERO_POINT;
        }
    }

    /**
     * 用浮点数创建点
     * @param x x轴坐标
     * @param y y轴坐标
     */
    public Point(float x, float y) {
        this.x = x;
        this.y = y;
    }

    /**
     * 用整数创建点
     * @param x x轴坐标
     * @param y y轴坐标
     */
    public Point(int x, int y) {
        this((float)x, (float)y);
    }

    /**
     * 获取x坐标值
     * @return x坐标
     */
    public final float getX() {
        return this.x;
    }

    /**
     * 获取y坐标值
     * @return y坐标
     */
    public final float getY() {
        return this.y;
    }

    /**
     * 复制点并创建新实例
     * @param x 新的x坐标
     * @param y 新的y坐标
     * @return 新的点对象
     */
    @NotNull
    public final Point copy(float x, float y) {
        return new Point(x, y);
    }

    /**
     * 获取当前点的拷贝
     * @return 和当前点相同的新点对象
     */
    public static Point copy$default(Point point, float x, float y, int flags, Object obj) {
        if ((flags & 1) != 0) {
            x = point.x;
        }
        if ((flags & 2) != 0) {
            y = point.y;
        }
        return point.copy(x, y);
    }

    /**
     * 点加法运算
     * @param other 另一个点
     * @return 两点坐标相加的结果
     */
    @NotNull
    public final Point plus(@NotNull Point other) {
        Intrinsics.checkNotNullParameter(other, "other");
        return new Point(this.x + other.x, this.y + other.y);
    }

    /**
     * 点减法运算
     * @param other 另一个点
     * @return 两点坐标相减的结果
     */
    @NotNull
    public final Point minus(@NotNull Point other) {
        Intrinsics.checkNotNullParameter(other, "other");
        return new Point(this.x - other.x, this.y - other.y);
    }

    /**
     * 点的缩放运算（乘法）
     * @param scalar 缩放因子
     * @return 坐标放大指定倍数的点
     */
    @NotNull
    public final Point times(float scalar) {
        return new Point(this.x * scalar, this.y * scalar);
    }

    /**
     * 点的缩放运算（除法）
     * @param scalar 缩放因子
     * @return 坐标缩小指定倍数的点
     */
    @NotNull
    public final Point div(float scalar) {
        return new Point(this.x / scalar, this.y / scalar);
    }

    /**
     * 计算点到原点的距离（点的模）
     * @return 距离值
     */
    public final float magnitude() {
        return (float) Math.sqrt(Math.pow(this.x, 2.0d) + Math.pow(this.y, 2.0d));
    }

    /**
     * 获取标准化的点（单位向量）
     * @return 保持方向但长度为1的点
     */
    @NotNull
    public final Point normalized() {
        return div(magnitude());
    }

    /**
     * 判断是否为零点
     * @return 如果是零点则返回true
     */
    public final boolean isZero() {
        return Intrinsics.areEqual(this, ZERO_POINT);
    }

    /**
     * 计算点与x轴正方向的夹角（角度制）
     * @return 0-360度之间的角度值
     */
    public final float rotationDegree() {
        return (((float) Math.toDegrees(Math.atan2(-this.y, this.x))) + 360.0f) % 360.0f;
    }

    /**
     * 重写equals方法
     */
    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Point)) {
            return false;
        }
        Point point = (Point) other;
        return Float.compare(this.x, point.x) == 0 && Float.compare(this.y, point.y) == 0;
    }

    /**
     * 重写hashCode方法
     */
    public int hashCode() {
        return (Float.hashCode(this.x) * 31) + Float.hashCode(this.y);
    }

    /**
     * 重写toString方法
     */
    @NotNull
    public String toString() {
        return "Point(x=" + this.x + ", y=" + this.y + ')';
    }
}